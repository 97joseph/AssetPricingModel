#run python classfier for calssification
python3 -m classfier

#making the directories for normal/abnormal plotting
mkdir Graph
mkdir Graph/Abnormal
mkdir Graph/Normal

#Running the Linear programming and plotting the data
python3 -m lpGeneratorPlot